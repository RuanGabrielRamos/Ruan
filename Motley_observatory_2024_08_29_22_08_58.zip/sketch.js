let ball;
let leftPaddle;
let rightPaddle;
0;
let leftScore = 0;
let rightScore = 0;

function setup() {
  createCanvas(800, 600);
  ball = new Ball();
  leftPaddle = new Paddle(true);
  rightPaddle = new Paddle(false);
}

function draw() {
  background(0);

  // Update and display ball
  ball.update();
  ball.show();

  // Update and display paddles
  leftPaddle.show();
  leftPaddle.update();

  rightPaddle.show();
  rightPaddle.update();

  // Check for ball collision with paddles
  if (ball.hits(leftPaddle) || ball.hits(rightPaddle)) {
    ball.xSpeed *= -1;
  }

  // Check for ball out of bounds and update score
  if (ball.offScreen()) {
    if (ball.x < 0) {
      rightScore++;
    } else if (ball.x > width) {
      leftScore++;
    }
    ball.reset();
  }

  // Display scores
  fill(255);
  textSize(32);
  textAlign(CENTER, TOP);
  text(leftScore, width / 4, 20);
  text(rightScore, (3 * width) / 4, 20);
}

function keyPressed() {
  if (key === "W") {
    leftPaddle.move(-10);
  } else if (key === "S") {
    leftPaddle.move(10);
  }

  if (keyCode === UP_ARROW) {
    rightPaddle.move(-10);
  } else if (keyCode === DOWN_ARROW) {
    rightPaddle.move(10);
  }
}

function keyReleased() {
  if (key === "W" || key === "S") {
    leftPaddle.move(0);
  }

  if (keyCode === UP_ARROW || keyCode === DOWN_ARROW) {
    rightPaddle.move(0);
  }
}

class Ball {
  constructor() {
    this.reset();
  }

  reset() {
    this.x = width / 2;
    this.y = height / 2;
    this.xSpeed = random(2, 5);
    this.ySpeed = random(2, 5);
  }

  update() {
    this.x += this.xSpeed;
    this.y += this.ySpeed;

    if (this.y < 0 || this.y > height) {
      this.ySpeed *= -1;
    }
  }

  show() {
    fill(255);
    noStroke();
    ellipse(this.x, this.y, 20, 20);
  }

  hits(paddle) {
    if (
      this.y > paddle.y &&
      this.y < paddle.y + paddle.height &&
      this.x > paddle.x &&
      this.x < paddle.x + paddle.width
    ) {
      return true;
    }
    return false;
  }

  offScreen() {
    return this.x < 0 || this.x > width;
  }
}

class Paddle {
  constructor(isLeft) {
    this.width = 20;
    this.height = 100;
    this.y = height / 2 - this.height / 2;
    this.x = isLeft ? 0 : width - this.width;
    this.ySpeed = 0;
  }

  update() {
    this.y += this.ySpeed;
    this.y = constrain(this.y, 0, height - this.height);
  }

  move(step) {
    this.ySpeed = step;
  }

  show() {
    fill(255);
    noStroke();
    rect(this.x, this.y, this.width, this.height);
  }
}
